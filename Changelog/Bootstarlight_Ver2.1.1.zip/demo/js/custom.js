// Scroll to top
$(function () {
    $(function () {
        $('html').append('<div class="scrollup"><a href="javascript:;" title="Scroll to top"></a></div>');
        $(window).scroll(function () {
            if ($(window).scrollTop() >= 50) {
                $('.scrollup').fadeIn(300);
            } else {
                $('.scrollup').fadeOut(300);
            }
        });
        $('.scrollup').click(function () {
            $('html,body').animate({ scrollTop: '0px' }, 800);
        });
    });
});
// SparkLine Bar
var $border_color = "#efefef";
var $grid_color = "#ddd";
var $default_black = "#666";
var $primary = "#575348";
var $secondary = "#8FBB6C";
var $orange = "#F38733";
$(function () {
  $('#currentSale').sparkline([23213, 63216, 82234, 29341, 61789, 88732, 11234, 54328, 33245], {
    type: 'bar',
    barColor: [$orange, $secondary],
    barWidth: 6,
    height: 18,
  });

  $('#currentBalance').sparkline([33251, 98123, 54312, 88763, 12341, 55672, 87904, 23412, 17632], {
    type: 'bar',
    barColor: [$secondary, $primary],
    barWidth: 6,
    height: 18,
  });
  
});

//Dropdown Menu
$( document ).ready(function() {
  $('#menu > ul > li > a').click(function() {
    $('#menu li').removeClass('active');
    $(this).closest('li').addClass('active'); 
    var checkElement = $(this).next();
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
      $(this).closest('li').removeClass('active');
      checkElement.slideUp('normal');
    }
    if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
      $('#menu ul ul:visible').slideUp('normal');
      checkElement.slideDown('normal');
    }
    if($(this).closest('li').find('ul').children().length == 0) {
      return true;
    } else {
      return false; 
    }   
  });
  //Dropdown sub sub Menu
  $('#menu > ul > li > ul > li > a').click(function() {
    $(this).closest('li').addClass('active'); 
    var checkElement = $(this).next();
    if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
        checkElement.slideUp('normal');
        $(this).closest('li').removeClass('active');
    }
    if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
       checkElement.slideDown('normal');
   }
    if ($(this).closest('li').find('ul').children().length == 0) {
      return true;
    } else {
        return false;
    }   
  });
});


$(function() {
  $(document).ready(function() {
    $.slidebars();
  });
});

//Sidebar
$(function() {
  var s = 0;
  
  $('.arrow-box').click(function() {
    if (s == 0) {
      s = 1;
      $('#sidebar').css('left', '-220px');
      $('.dashboard-wrapper').css('margin-left', '0px');
      $('.logo').css('background', 'transparent');
    } else {
      s = 0;
      $('#sidebar').css('left', '0');
      $('.dashboard-wrapper').css('margin-left', '220px');
      $('.logo').css('background', '');
    }
  });
});

//
$('#mob-nav').click(function(){
  if($('aside.open').length > 0){
    $('aside').attr('style', 'left: -220px').removeClass('open')
  } else {
    $('aside').attr('style', 'left: 0px').addClass('open')
  }
});